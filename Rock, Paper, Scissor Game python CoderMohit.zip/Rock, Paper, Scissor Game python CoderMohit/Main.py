# Visit https://codermohit.com/python-project/ for More Projects.
from tkinter import *

import random
from tkinter import messagebox

root = Tk()
root.title("Rock, Paper, Scissor Game")
width = 700
height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width / 2) - (width / 2)
y = (screen_height / 2) - (height / 2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)
root.config(bg="#f56d40")

# ================================IMAGES========================================
blank_img = PhotoImage(file="images/blank.png")
player_rock = PhotoImage(file="images/player_rock.png")
sm_player_rock = player_rock.subsample(3, 3)
player_paper = PhotoImage(file="images/player_paper.png")
sm_player_paper = player_paper.subsample(3, 3)
player_scissor = PhotoImage(file="images/player_scissor.png")
sm_player_scissor = player_scissor.subsample(3, 3)
com_rock = PhotoImage(file="images/com_rock.png")
com_paper = PhotoImage(file="images/com_paper.png")
com_scissor = PhotoImage(file="images/com_scissor.png")


# ===============================METHODS========================================
def Rock():
    global player_choice
    player_choice = 1
    player_img.configure(image=player_rock)
    MatchProcess()


def Paper():
    global player_choice
    player_choice = 2
    player_img.configure(image=player_paper)
    MatchProcess()


def Scissor():
    global player_choice
    player_choice = 3
    player_img.configure(image=player_scissor)
    MatchProcess()


def MatchProcess():
    com_choice = random.randint(1, 3)
    if com_choice == 1:
        comp_img.configure(image=com_rock)
        ComputerRock()
    elif com_choice == 2:
        comp_img.configure(image=com_paper)
        ComputerPaper()

    elif com_choice == 3:
        comp_img.configure(image=com_scissor)
        CompututerScissor()


def ComputerRock():
    if player_choice == 1:
        lbl_status.config(text="Game Tie")
    elif player_choice == 2:
        lbl_status.config(text="You Win")
    elif player_choice == 3:
        lbl_status.config(text="Computer Win")


def ComputerPaper():
    if player_choice == 1:
        lbl_status.config(text="Computer Win")
    elif player_choice == 2:
        lbl_status.config(text="Game Tie")
    elif player_choice == 3:
        lbl_status.config(text="You Win")


def CompututerScissor():
    if player_choice == 1:
        lbl_status.config(text="You Win")
    elif player_choice == 2:
        lbl_status.config(text="Computer Win")
    elif player_choice == 3:
        lbl_status.config(text="Game Tie")


def ExitApp():
    root.destroy()
    exit()




name = input("Enter Your Name : ")
# ===============================LABEL WIDGET=========================================
player_img = Label(root, image=blank_img)
comp_img = Label(root, image=blank_img)
lbl_player = Label(root, text=name,width=10,font=('Helvetica', 15, 'italic','bold'))
lbl_player.place(x=140, y=120)
lbl_player.config()
lbl_computer = Label(root, text='Computer',width=10,font=('Helvetica', 15,'italic','bold'))
lbl_computer.place(x=440, y=120)

lbl_computer.config()
lbl_status = Label(root, text='',width=20,fg = 'white',font=('Helvetica', 15, 'bold'))
lbl_status.config(bg="#f56d40")
player_img.place(x=100, y=150)
comp_img.place(x=400, y=150)
lbl_status.place(x=240, y=370)

# ===============================BUTTON WIDGET===================================
rock = Button(root, image=sm_player_rock, command=Rock)
paper = Button(root, image=sm_player_paper, command=Paper)
scissor = Button(root, image=sm_player_scissor, command=Scissor)
btn_quit = Button(root, bg='#8B0000',fg='white',width=15, text="Quit", font=('Courier', 15, 'bold'), command=ExitApp)

rock.place(x=50, y=500)
paper.place(x=200, y=500)
scissor.place(x=350, y=500)
btn_quit.place(x=500, y=550)

# ========================================INITIALIZATION===================================
if __name__ == '__main__':
    root.mainloop()
